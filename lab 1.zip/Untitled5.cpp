#include<iostream>
using namespace std;
class concrete {
	private:
	string msg;

	public:
		concrete(string m)
		{
			msg=m;
		}

   void display()
   {
   	cout<<"the msg is: "<<msg<<endl;
   }
};
int main ()
{
	concrete obj("hi! i am muskan makhija");
	obj.display();
}