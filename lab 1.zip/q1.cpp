#include<iostream>
using namespace std;
class student
{
	public:
	string name;
	int rollnum;

};
int main ()
{
	student s1;
	s1.name="muskan makhija";
	s1.rollnum=661;
	cout<<"name of student is: "<<s1.name<<", roll num: "<<s1.rollnum;


}